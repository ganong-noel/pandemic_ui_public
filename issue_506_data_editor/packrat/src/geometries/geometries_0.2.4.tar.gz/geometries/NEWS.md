
# 0.2.4

* factor levels remain [sfheaders issue 89](https://github.com/dcooley/sfheaders/issues/89)

# 0.2.2

* removed C++ system requirements

# 0.2.1

* updated C++ dependencies
* `nest_impl()` function for nesting & un-nesting lists

# 0.2.0

* user can add `closed` attribute added to shapes if the first row is repeated at the end of a matrix
* `nest.hpp` - re-enabled
* `columns.hpp` - templated `column_positions()` and handles data.frame inputs
