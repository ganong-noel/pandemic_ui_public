library(testthat)
library(sfheaders)

test_check("sfheaders")
